-- ============================================================
-- Схема базы данных для Cadence Planner
-- ============================================================
-- КАК ПРИМЕНИТЬ:
-- 1. Зайдите на supabase.com → создайте новый проект (бесплатно)
-- 2. В левом меню откройте "SQL Editor"
-- 3. Вставьте весь этот файл целиком и нажмите "Run"
-- ============================================================

create table if not exists users (
  id bigserial primary key,
  telegram_id bigint unique not null,
  telegram_username text,
  first_name text,

  -- Онбординг / персонализация
  niche text,                          -- ниша пользовательницы, например "фитнес-тренер"
  pillars jsonb default '[]'::jsonb,   -- массив контент-пилларов: [{"key":"growth","label":"Рост"}, ...]
  onboarding_done boolean default false,

  -- Подписка
  subscription_status text default 'trial',   -- trial | active | expired | cancelled
  subscription_ends_at timestamptz,
  stripe_customer_id text,
  stripe_subscription_id text,

  -- Служебное
  created_at timestamptz default now(),
  last_reminder_sent_at timestamptz
);

-- Посты, которые пользовательница добавила в план
create table if not exists posts (
  id bigserial primary key,
  user_id bigint references users(id) on delete cascade,
  title text not null,
  pillar_key text,
  platform text default 'Feed',
  post_date date not null,
  is_done boolean default false,
  created_at timestamptz default now()
);

-- Еженедельные AI-идеи, сгенерированные для пользовательницы
create table if not exists weekly_ideas (
  id bigserial primary key,
  user_id bigint references users(id) on delete cascade,
  title text not null,
  hook text,
  pillar_key text,
  week_of date not null,          -- понедельник той недели, для которой сгенерировано
  created_at timestamptz default now()
);

create index if not exists idx_users_telegram_id on users(telegram_id);
create index if not exists idx_posts_user_date on posts(user_id, post_date);
create index if not exists idx_ideas_user_week on weekly_ideas(user_id, week_of);
